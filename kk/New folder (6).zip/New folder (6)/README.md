# Car Listings Web App

A simple web application for listing and browsing cars for sale. Built with Flask and SQLite.

## Features

- Browse car listings with images and details
- Add new car listings with image upload
- Search cars by title
- Filter cars by price range and year
- View detailed information about each car
- Delete car listings
- Responsive design using Bootstrap

## Requirements

- Python 3.7 or higher
- Flask and other dependencies (listed in requirements.txt)

## Setup Instructions

1. Clone the repository:
```bash
git clone <repository-url>
cd car-listings
```

2. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the application:
```bash
python app.py
```

5. Open your web browser and navigate to:
```
http://localhost:5000
```

## Project Structure

```
car-listings/
├── app.py              # Main Flask application
├── requirements.txt    # Python dependencies
├── static/            # Static files (CSS, images)
│   └── uploads/       # Uploaded car images
├── templates/         # HTML templates
│   ├── base.html      # Base template
│   ├── home.html      # Home page
│   ├── add_car.html   # Add car form
│   └── car_detail.html # Car details page
└── cars.db           # SQLite database (created automatically)
```

## Usage

1. Home Page: View all car listings and use search/filter options
2. Add Car: Click "Add Car" in the navigation to create a new listing
3. View Details: Click "View Details" on any car card to see full information
4. Delete: Use the delete button to remove a listing

## Notes

- The application uses SQLite as a simple database solution
- Images are stored in the static/uploads directory
- Authentication system is now implemented (users must sign up and log in to add listings)
- The application is designed for local use and development 